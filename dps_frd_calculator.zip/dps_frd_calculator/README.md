# DPS & FDR Calculator

A Bangladesh-specific Deposit Pension Scheme (DPS) and Fixed Deposit Receipt (FDR) calculator with proper tax and excise duty calculations.

## Features

- **DPS Calculator**: Monthly deposit scheme with compound interest
- **FDR Calculator**: Fixed deposit (lump sum) with compound interest
- **Bangladesh Tax Rules**:
  - Source Tax: 10% (with Tax Return/TIN) or 15% (without)
  - Excise Duty: Yearly deduction based on highest balance slab
- **Languages**: English and Bangla
- **Detailed Schedule**: Month-by-month breakdown with all deductions

## Excise Duty Slabs (Yearly)

| Balance Range | Excise Duty |
|---------------|-------------|
| 0 – 4,00,000 | 0 |
| 4,00,001 – 5,00,000 | 150 |
| 5,00,001 – 10,00,000 | 500 |
| 10,00,001 – 50,00,000 | 3,000 |
| 50,00,001 – 1,00,00,000 | 5,000 |
| 1,00,00,001 – 2,00,00,000 | 10,000 |
| 2,00,00,001 – 5,00,00,000 | 20,000 |
| 5,00,00,001+ | 50,000 |

## Project Structure

```
dps_frd_calculator/
├── app/
│   ├── src/main/
│   │   ├── java/com/example/dpsfrdcalc/
│   │   │   ├── CalculationEngine.kt   # Core calculation logic
│   │   │   ├── MainActivity.kt        # Main screen (Compose)
│   │   │   └── DetailsActivity.kt     # Monthly breakdown
│   │   ├── res/
│   │   │   ├── values/strings.xml     # English strings
│   │   │   └── values-bn/strings.xml  # Bangla strings
│   │   └── AndroidManifest.xml
│   └── build.gradle.kts
├── build.gradle.kts
├── settings.gradle.kts
└── gradle/libs.versions.toml
```

## Build Instructions

1. Open in **Android Studio Koala (2024.1.1)** or later
2. Let Gradle sync and download dependencies
3. Build → Run on emulator or device

## Web Prototype

A standalone HTML/JS version is available in `prototype/index.html` - open directly in any browser (mobile or desktop) to test calculations immediately.

## GitHub Push

```bash
git init
git add .
git commit -m "Initial commit: DPS & FDR Calculator"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/dps-frd-calculator.git
git push -u origin main
```

## License

MIT License - Feel free to use and modify.