package com.example.dpsfrdcalc

/**
 * Excise Duty Slab (Bangladesh Bank rules)
 * Based on highest balance in the calendar year
 */
object ExciseDutyCalculator {
    fun calculate(highestBalance: Double): Double {
        return when {
            highestBalance <= 400_000 -> 0.0
            highestBalance <= 500_000 -> 150.0
            highestBalance <= 1_000_000 -> 500.0
            highestBalance <= 5_000_000 -> 3_000.0
            highestBalance <= 10_000_000 -> 5_000.0
            highestBalance <= 20_000_000 -> 10_000.0
            highestBalance <= 50_000_000 -> 20_000.0
            else -> 50_000.0
        }
    }
}

/**
 * Monthly schedule entry for detailed breakdown
 */
data class MonthSchedule(
    val month: Int,
    val deposit: Double,
    val totalDeposited: Double,
    val grossInterest: Double,
    val tax: Double,
    val excise: Double,
    val endingBalance: Double
)

/**
 * Calculation result data class
 */
data class CalculationResult(
    val type: String, // "DPS" or "FDR"
    val totalDeposited: Double,
    val grossInterest: Double,
    val taxDeducted: Double,
    val exciseDuty: Double,
    val totalDeductions: Double,
    val maturityGross: Double,
    val takeHome: Double,
    val schedule: List<MonthSchedule>
)

/**
 * Main calculation engine for DPS and FDR
 */
object CalculationEngine {

    /**
     * Calculate DPS (Monthly Deposit Scheme)
     * @param monthlyDeposit Monthly installment amount
     * @param annualRate Annual interest rate (percentage)
     * @param durationMonths Duration in months
     * @param hasTin true if user has Tax Return (10% tax), false otherwise (15% tax)
     */
    fun calculateDPS(
        monthlyDeposit: Double,
        annualRate: Double,
        durationMonths: Int,
        hasTin: Boolean = true
    ): CalculationResult {
        val monthlyRate = (annualRate / 100.0) / 12.0
        val taxRate = if (hasTin) 0.10 else 0.15

        var currentBalance = 0.0
        var totalDeposited = 0.0
        var totalGrossInterest = 0.0
        var totalTaxDeducted = 0.0
        var totalExciseDuty = 0.0
        val schedule = mutableListOf<MonthSchedule>()

        for (month in 1..durationMonths) {
            // Deposit at start of month
            totalDeposited += monthlyDeposit
            currentBalance += monthlyDeposit

            // Calculate monthly interest
            val monthlyInterest = currentBalance * monthlyRate
            val monthlyTax = monthlyInterest * taxRate
            val netMonthlyInterest = monthlyInterest - monthlyTax

            totalGrossInterest += monthlyInterest
            totalTaxDeducted += monthlyTax
            currentBalance += netMonthlyInterest

            // Excise duty deducted once every 12 months
            var exciseThisMonth = 0.0
            if (month % 12 == 0) {
                exciseThisMonth = ExciseDutyCalculator.calculate(currentBalance)
                totalExciseDuty += exciseThisMonth
                currentBalance -= exciseThisMonth
            }

            schedule.add(
                MonthSchedule(
                    month = month,
                    deposit = monthlyDeposit,
                    totalDeposited = totalDeposited,
                    grossInterest = monthlyInterest,
                    tax = monthlyTax,
                    excise = exciseThisMonth,
                    endingBalance = currentBalance
                )
            )
        }

        val maturityGross = totalDeposited + totalGrossInterest
        val totalDeductions = totalTaxDeducted + totalExciseDuty

        return CalculationResult(
            type = "DPS",
            totalDeposited = totalDeposited,
            grossInterest = totalGrossInterest,
            taxDeducted = totalTaxDeducted,
            exciseDuty = totalExciseDuty,
            totalDeductions = totalDeductions,
            maturityGross = maturityGross,
            takeHome = currentBalance,
            schedule = schedule
        )
    }

    /**
     * Calculate FDR (Fixed Deposit Receipt)
     * @param principal Lump sum principal amount
     * @param annualRate Annual interest rate (percentage)
     * @param durationMonths Duration in months
     * @param hasTin true if user has Tax Return (10% tax), false otherwise (15% tax)
     */
    fun calculateFDR(
        principal: Double,
        annualRate: Double,
        durationMonths: Int,
        hasTin: Boolean = true
    ): CalculationResult {
        val monthlyRate = (annualRate / 100.0) / 12.0
        val taxRate = if (hasTin) 0.10 else 0.15

        var currentBalance = principal
        val totalDeposited = principal
        var totalGrossInterest = 0.0
        var totalTaxDeducted = 0.0
        var totalExciseDuty = 0.0
        val schedule = mutableListOf<MonthSchedule>()

        for (month in 1..durationMonths) {
            // Calculate monthly interest
            val monthlyInterest = currentBalance * monthlyRate
            val monthlyTax = monthlyInterest * taxRate
            val netMonthlyInterest = monthlyInterest - monthlyTax

            totalGrossInterest += monthlyInterest
            totalTaxDeducted += monthlyTax
            currentBalance += netMonthlyInterest

            // Excise duty deducted once every 12 months
            var exciseThisMonth = 0.0
            if (month % 12 == 0) {
                exciseThisMonth = ExciseDutyCalculator.calculate(currentBalance)
                totalExciseDuty += exciseThisMonth
                currentBalance -= exciseThisMonth
            }

            schedule.add(
                MonthSchedule(
                    month = month,
                    deposit = if (month == 1) principal else 0.0,
                    totalDeposited = totalDeposited,
                    grossInterest = monthlyInterest,
                    tax = monthlyTax,
                    excise = exciseThisMonth,
                    endingBalance = currentBalance
                )
            )
        }

        val maturityGross = totalDeposited + totalGrossInterest
        val totalDeductions = totalTaxDeducted + totalExciseDuty

        return CalculationResult(
            type = "FDR",
            totalDeposited = totalDeposited,
            grossInterest = totalGrossInterest,
            taxDeducted = totalTaxDeducted,
            exciseDuty = totalExciseDuty,
            totalDeductions = totalDeductions,
            maturityGross = maturityGross,
            takeHome = currentBalance,
            schedule = schedule
        )
    }
}
