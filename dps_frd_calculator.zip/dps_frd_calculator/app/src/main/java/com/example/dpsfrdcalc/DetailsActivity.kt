package com.example.dpsfrdcalc

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class DetailsActivity : ComponentActivity() {
    companion object {
        var currentResult: CalculationResult? = null
    }

    @OptIn(ExperimentalMaterial3Api::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val result = currentResult

        setContent {
            MaterialTheme {
                Scaffold(
                    topBar = {
                        TopAppBar(
                            title = {
                                Text(
                                    stringResource(R.string.title_schedule) + " (${result?.type ?: ""})",
                                    fontWeight = FontWeight.Bold
                                )
                            },
                            navigationIcon = {
                                IconButton(onClick = { finish() }) {
                                    Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                                }
                            },
                            colors = TopAppBarDefaults.topAppBarColors(
                                containerColor = MaterialTheme.colorScheme.primary,
                                titleContentColor = Color.White
                            )
                        )
                    }
                ) { innerPadding ->
                    if (result != null) {
                        ScheduleList(result, Modifier.padding(innerPadding))
                    } else {
                        Text("No data available", modifier = Modifier.padding(16.dp))
                    }
                }
            }
        }
    }
}

@Composable
fun ScheduleList(result: CalculationResult, modifier: Modifier = Modifier) {
    Column(modifier = modifier.fillMaxSize()) {
        // Table Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFFE0E0E0))
                .padding(vertical = 10.dp, horizontal = 8.dp)
        ) {
            Text(stringResource(R.string.col_month), modifier = Modifier.weight(0.8f), fontWeight = FontWeight.Bold, fontSize = 12.sp)
            Text(stringResource(R.string.col_deposit), modifier = Modifier.weight(1.2f), fontWeight = FontWeight.Bold, fontSize = 12.sp)
            Text(stringResource(R.string.col_interest), modifier = Modifier.weight(1.2f), fontWeight = FontWeight.Bold, fontSize = 12.sp)
            Text(stringResource(R.string.col_tax), modifier = Modifier.weight(1.0f), fontWeight = FontWeight.Bold, fontSize = 12.sp)
            Text(stringResource(R.string.col_excise), modifier = Modifier.weight(1.0f), fontWeight = FontWeight.Bold, fontSize = 12.sp)
            Text(stringResource(R.string.col_balance), modifier = Modifier.weight(1.4f), fontWeight = FontWeight.Bold, fontSize = 12.sp)
        }
        Divider()

        // Table Rows
        LazyColumn(modifier = Modifier.fillMaxSize()) {
            items(result.schedule) { row ->
                val isExciseMonth = row.excise > 0
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(if (isExciseMonth) Color(0xFFFFEBEE) else Color.White)
                        .padding(vertical = 8.dp, horizontal = 8.dp)
                ) {
                    Text("${row.month}", modifier = Modifier.weight(0.8f), fontSize = 11.sp)
                    Text(formatShort(row.deposit), modifier = Modifier.weight(1.2f), fontSize = 11.sp)
                    Text(formatShort(row.grossInterest), modifier = Modifier.weight(1.2f), fontSize = 11.sp)
                    Text(formatShort(row.tax), modifier = Modifier.weight(1.0f), fontSize = 11.sp, color = Color.Red)
                    Text(formatShort(row.excise), modifier = Modifier.weight(1.0f), fontSize = 11.sp, color = if (isExciseMonth) Color.Red else Color.Gray)
                    Text(formatShort(row.endingBalance), modifier = Modifier.weight(1.4f), fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                }
                Divider(color = Color(0xFFEEEEEE))
            }
        }
    }
}

fun formatShort(amount: Double): String {
    return if (amount == 0.0) "-" else String.format("৳%,.0f", amount)
}
