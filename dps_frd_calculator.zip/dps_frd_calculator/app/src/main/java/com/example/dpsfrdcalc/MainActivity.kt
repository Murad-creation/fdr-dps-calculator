package com.example.dpsfrdcalc

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.NumberFormat
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = lightColorScheme(
                    primary = Color(0xFF0D47A1),
                    secondary = Color(0xFF1976D2),
                    surface = Color(0xFFF5F5F5)
                )
            ) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    MainScreen(onViewDetails = { result ->
                        val intent = Intent(this, DetailsActivity::class.java)
                        // Pass data via intent or static state
                        DetailsActivity.currentResult = result
                        startActivity(intent)
                    })
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(onViewDetails: (CalculationResult) -> Unit) {
    var selectedTab by remember { mutableStateOf(0) } // 0 = DPS, 1 = FDR

    // Form inputs
    var amountInput by remember { mutableStateOf("5000") }
    var rateInput by remember { mutableStateOf("9.0") }
    var yearsInput by remember { mutableStateOf("3") }
    var monthsInput by remember { mutableStateOf("0") }
    var hasTin by remember { mutableStateOf(true) }

    var calcResult by remember { mutableStateOf<CalculationResult?>(null) }

    val bdtFormat = remember { NumberFormat.getCurrencyInstance(Locale("bn", "BD")) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.app_name), fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = Color.White
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Tab Selector
            TabRow(selectedTabIndex = selectedTab) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = {
                        selectedTab = 0
                        if (amountInput == "500000") amountInput = "5000"
                        calcResult = null
                    },
                    text = { Text(stringResource(R.string.tab_dps), fontSize = 16.sp) }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = {
                        selectedTab = 1
                        if (amountInput == "5000") amountInput = "500000"
                        calcResult = null
                    },
                    text = { Text(stringResource(R.string.tab_fdr), fontSize = 16.sp) }
                )
            }

            // Input Fields Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedTextField(
                        value = amountInput,
                        onValueChange = { amountInput = it },
                        label = {
                            Text(
                                if (selectedTab == 0)
                                    stringResource(R.string.label_monthly_deposit)
                                else
                                    stringResource(R.string.label_principal_amount)
                            )
                        },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = rateInput,
                        onValueChange = { rateInput = it },
                        label = { Text(stringResource(R.string.label_interest_rate)) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = yearsInput,
                            onValueChange = { yearsInput = it },
                            label = { Text(stringResource(R.string.label_tenor_years)) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = monthsInput,
                            onValueChange = { monthsInput = it },
                            label = { Text(stringResource(R.string.label_tenor_months)) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f)
                        )
                    }

                    // TIN / Tax Switch
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                stringResource(R.string.label_tax_return),
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                stringResource(R.string.tax_return_hint),
                                fontSize = 12.sp,
                                color = Color.Gray
                            )
                        }
                        Switch(
                            checked = hasTin,
                            onCheckedChange = { hasTin = it }
                        )
                    }

                    Button(
                        onClick = {
                            val amount = amountInput.toDoubleOrNull() ?: 0.0
                            val rate = rateInput.toDoubleOrNull() ?: 0.0
                            val yrs = yearsInput.toIntOrNull() ?: 0
                            val mths = monthsInput.toIntOrNull() ?: 0
                            val totalMonths = (yrs * 12) + mths

                            if (amount > 0 && rate > 0 && totalMonths > 0) {
                                calcResult = if (selectedTab == 0) {
                                    CalculationEngine.calculateDPS(
                                        monthlyDeposit = amount,
                                        annualRate = rate,
                                        durationMonths = totalMonths,
                                        hasTin = hasTin
                                    )
                                } else {
                                    CalculationEngine.calculateFDR(
                                        principal = amount,
                                        annualRate = rate,
                                        durationMonths = totalMonths,
                                        hasTin = hasTin
                                    )
                                }
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                    ) {
                        Text(stringResource(R.string.btn_calculate), fontSize = 18.sp)
                    }
                }
            }

            // Results Display Card
            calcResult?.let { res ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFE3F2FD))
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            stringResource(R.string.title_summary),
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Divider()

                        ResultRow(stringResource(R.string.label_total_deposited), formatAmount(res.totalDeposited))
                        ResultRow(stringResource(R.string.label_gross_interest), formatAmount(res.grossInterest))
                        ResultRow(stringResource(R.string.label_gross_maturity), formatAmount(res.maturityGross), bold = true)

                        Spacer(modifier = Modifier.height(4.dp))
                        Text("কর্তনসমূহ / Deductions:", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                        ResultRow(stringResource(R.string.label_source_tax) + " (${if (res.hasTin) "10%" else "15%"})", "- " + formatAmount(res.taxDeducted), color = Color(0xFFC62828))
                        ResultRow(stringResource(R.string.label_excise_duty), "- " + formatAmount(res.exciseDuty), color = Color(0xFFC62828))
                        ResultRow(stringResource(R.string.label_total_deductions), "- " + formatAmount(res.totalDeductions), color = Color(0xFFC62828), bold = true)

                        Divider(modifier = Modifier.padding(vertical = 4.dp))

                        // Big Take-home card
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color(0xFF1B5E20), RoundedCornerShape(8.dp))
                                .padding(16.dp)
                        ) {
                            Column {
                                Text(
                                    stringResource(R.string.label_take_home),
                                    color = Color.White,
                                    fontSize = 14.sp
                                )
                                Text(
                                    formatAmount(res.takeHome),
                                    color = Color.White,
                                    fontSize = 24.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        OutlinedButton(
                            onClick = { onViewDetails(res) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 8.dp)
                        ) {
                            Text(stringResource(R.string.btn_view_details))
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ResultRow(label: String, value: String, bold: Boolean = false, color: Color = Color.Unspecified) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, fontSize = 14.sp, fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal)
        Text(
            value,
            fontSize = 14.sp,
            fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal,
            color = color
        )
    }
}

fun formatAmount(amount: Double): String {
    return String.format(Locale.US, "৳ %,.2f", amount)
}
