<#
.SYNOPSIS
    Push DPS & FDR Calculator to GitHub
.DESCRIPTION
    Initializes git, commits, and pushes to GitHub.
    Run this from the project root directory in PowerShell.
#>

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  DPS & FDR Calculator - GitHub Push   " -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# Check if we're in the right directory
if (-not (Test-Path "settings.gradle.kts") -or -not (Test-Path "app")) {
    Write-Host "Error: Please run this script from the project root directory (where settings.gradle.kts is)" -ForegroundColor Red
    exit 1
}

# Get GitHub username
Write-Host "Enter your GitHub username:" -ForegroundColor Yellow
$githubUser = Read-Host

if ([string]::IsNullOrWhiteSpace($githubUser)) {
    Write-Host "Error: GitHub username cannot be empty" -ForegroundColor Red
    exit 1
}

$repoName = "dps-frd-calculator"
$repoUrl = "https://github.com/${githubUser}/${repoName}.git"

Write-Host ""
Write-Host "Repository: $repoUrl" -ForegroundColor Cyan
Write-Host ""

# Check if git is initialized
if (-not (Test-Path ".git")) {
    Write-Host "Initializing git repository..." -ForegroundColor Yellow
    git init
    git branch -M main
} else {
    Write-Host "Git repository already initialized" -ForegroundColor Green
}

# Check if remote exists
$remotes = git remote
if ($remotes -contains "origin") {
    Write-Host "Remote 'origin' already exists. Updating..." -ForegroundColor Yellow
    git remote set-url origin $repoUrl
} else {
    Write-Host "Adding remote origin..." -ForegroundColor Yellow
    git remote add origin $repoUrl
}

# Stage all files
Write-Host "Staging files..." -ForegroundColor Yellow
git add .

# Check if there are changes to commit
$status = git status --porcelain
if (-not $status) {
    Write-Host "No changes to commit" -ForegroundColor Yellow
} else {
    Write-Host "Committing changes..." -ForegroundColor Yellow
    $commitMsg = @"
Initial commit: DPS & FDR Calculator with Bangladesh tax & excise duty rules

- DPS (Monthly Deposit Scheme) calculator
- FDR (Fixed Deposit Receipt) calculator
- Bangladesh Source Tax: 10% (with TIN) / 15% (without TIN)
- Yearly Excise Duty based on highest balance slab
- Bilingual: English & Bangla
- Monthly breakdown schedule
- Android app (Kotlin + Jetpack Compose)
- Web prototype (HTML/JS)
"@
    git commit -m $commitMsg
}

# Push to GitHub
Write-Host ""
Write-Host "Pushing to GitHub..." -ForegroundColor Cyan
Write-Host "You may be prompted for your GitHub credentials (username + Personal Access Token)" -ForegroundColor Yellow
Write-Host ""

try {
    git push -u origin main
    Write-Host ""
    Write-Host "========================================" -ForegroundColor Green
    Write-Host "  ✓ Successfully pushed to GitHub!     " -ForegroundColor Green
    Write-Host "========================================" -ForegroundColor Green
    Write-Host ""
    Write-Host "Repository URL: https://github.com/${githubUser}/${repoName}" -ForegroundColor Cyan
} catch {
    Write-Host ""
    Write-Host "========================================" -ForegroundColor Red
    Write-Host "  ✗ Push failed                        " -ForegroundColor Red
    Write-Host "========================================" -ForegroundColor Red
    Write-Host ""
    Write-Host "Troubleshooting:" -ForegroundColor Yellow
    Write-Host "1. Make sure the repository exists on GitHub"
    Write-Host "2. Use a Personal Access Token (not password) for authentication"
    Write-Host "3. Create token at: https://github.com/settings/tokens"
    Write-Host "4. Token needs 'repo' scope"
    exit 1
}