#!/bin/bash
# ============================================================
# Push DPS & FDR Calculator to GitHub
# Run this script from the project root directory
# ============================================================

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo -e "${BLUE}========================================${NC}"
echo -e "${BLUE}  DPS & FDR Calculator - GitHub Push   ${NC}"
echo -e "${BLUE}========================================${NC}"
echo

# Check if we're in the right directory
if [ ! -f "settings.gradle.kts" ] || [ ! -d "app" ]; then
    echo -e "${RED}Error: Please run this script from the project root directory (where settings.gradle.kts is)${NC}"
    exit 1
fi

# Get GitHub username
echo -e "${YELLOW}Enter your GitHub username:${NC}"
read -r GITHUB_USER

if [ -z "$GITHUB_USER" ]; then
    echo -e "${RED}Error: GitHub username cannot be empty${NC}"
    exit 1
fi

REPO_NAME="dps-frd-calculator"
REPO_URL="https://github.com/${GITHUB_USER}/${REPO_NAME}.git"

echo
echo -e "${BLUE}Repository: ${REPO_URL}${NC}"
echo

# Check if git is initialized
if [ ! -d ".git" ]; then
    echo -e "${YELLOW}Initializing git repository...${NC}"
    git init
    git branch -M main
else
    echo -e "${GREEN}Git repository already initialized${NC}"
fi

# Check if remote exists
if git remote | grep -q "origin"; then
    echo -e "${YELLOW}Remote 'origin' already exists. Updating...${NC}"
    git remote set-url origin "$REPO_URL"
else
    echo -e "${YELLOW}Adding remote origin...${NC}"
    git remote add origin "$REPO_URL"
fi

# Stage all files
echo -e "${YELLOW}Staging files...${NC}"
git add .

# Check if there are changes to commit
if git diff --cached --quiet; then
    echo -e "${YELLOW}No changes to commit${NC}"
else
    echo -e "${YELLOW}Committing changes...${NC}"
    git commit -m "Initial commit: DPS & FDR Calculator with Bangladesh tax & excise duty rules

- DPS (Monthly Deposit Scheme) calculator
- FDR (Fixed Deposit Receipt) calculator
- Bangladesh Source Tax: 10% (with TIN) / 15% (without TIN)
- Yearly Excise Duty based on highest balance slab
- Bilingual: English & Bangla
- Monthly breakdown schedule
- Android app (Kotlin + Jetpack Compose)
- Web prototype (HTML/JS)
"
fi

# Push to GitHub
echo
echo -e "${BLUE}Pushing to GitHub...${NC}"
echo -e "${YELLOW}You may be prompted for your GitHub credentials (username + Personal Access Token)${NC}"
echo

if git push -u origin main; then
    echo
    echo -e "${GREEN}========================================${NC}"
    echo -e "${GREEN}  ✓ Successfully pushed to GitHub!     ${NC}"
    echo -e "${GREEN}========================================${NC}"
    echo
    echo -e "${BLUE}Repository URL: https://github.com/${GITHUB_USER}/${REPO_NAME}${NC}"
else
    echo
    echo -e "${RED}========================================${NC}"
    echo -e "${RED}  ✗ Push failed                        ${NC}"
    echo -e "${RED}========================================${NC}"
    echo
    echo -e "${YELLOW}Troubleshooting:${NC}"
    echo "1. Make sure the repository exists on GitHub"
    echo "2. Use a Personal Access Token (not password) for authentication"
    echo "3. Create token at: https://github.com/settings/tokens"
    echo "4. Token needs 'repo' scope"
    exit 1
fi