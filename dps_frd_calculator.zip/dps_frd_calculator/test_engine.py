"""
Calculation Logic for DPS and FDR with Bangladesh Tax & Excise Duty rules.
"""

def get_excise_duty(highest_balance):
    if highest_balance <= 400000:
        return 0
    elif highest_balance <= 500000:
        return 150
    elif highest_balance <= 1000000:
        return 500
    elif highest_balance <= 5000000:
        return 3000
    elif highest_balance <= 10000000:
        return 5000
    elif highest_balance <= 20000000:
        return 10000
    elif highest_balance <= 50000000:
        return 20000
    else:
        return 50000

def calculate_dps(monthly_deposit, annual_rate, duration_months, has_tin=True):
    r = (annual_rate / 100) / 12
    tax_rate = 0.10 if has_tin else 0.15

    schedule = []
    current_balance = 0
    total_deposited = 0
    total_gross_interest = 0
    total_tax_deducted = 0
    total_excise_duty = 0

    for month in range(1, duration_months + 1):
        total_deposited += monthly_deposit
        current_balance += monthly_deposit

        monthly_interest = current_balance * r
        monthly_tax = monthly_interest * tax_rate
        net_monthly_interest = monthly_interest - monthly_tax

        total_gross_interest += monthly_interest
        total_tax_deducted += monthly_tax

        current_balance += net_monthly_interest

        excise_this_month = 0
        if month % 12 == 0:
            excise_this_month = get_excise_duty(current_balance)
            total_excise_duty += excise_this_month
            current_balance -= excise_this_month

        schedule.append({
            'month': month,
            'deposit': monthly_deposit,
            'total_deposited': total_deposited,
            'gross_interest': monthly_interest,
            'tax': monthly_tax,
            'excise': excise_this_month,
            'ending_balance': current_balance
        })

    maturity_gross = total_deposited + total_gross_interest
    total_deductions = total_tax_deducted + total_excise_duty
    take_home = current_balance

    return {
        'type': 'DPS',
        'monthly_deposit': monthly_deposit,
        'duration_months': duration_months,
        'annual_rate': annual_rate,
        'has_tin': has_tin,
        'total_deposited': total_deposited,
        'gross_interest': total_gross_interest,
        'tax_deducted': total_tax_deducted,
        'excise_duty': total_excise_duty,
        'total_deductions': total_deductions,
        'maturity_gross': maturity_gross,
        'take_home': take_home,
        'schedule': schedule
    }

def calculate_fdr(principal, annual_rate, duration_months, has_tin=True):
    r = (annual_rate / 100) / 12
    tax_rate = 0.10 if has_tin else 0.15

    schedule = []
    current_balance = principal
    total_deposited = principal
    total_gross_interest = 0
    total_tax_deducted = 0
    total_excise_duty = 0

    for month in range(1, duration_months + 1):
        monthly_interest = current_balance * r
        monthly_tax = monthly_interest * tax_rate
        net_monthly_interest = monthly_interest - monthly_tax

        total_gross_interest += monthly_interest
        total_tax_deducted += monthly_tax
        current_balance += net_monthly_interest

        excise_this_month = 0
        if month % 12 == 0:
            excise_this_month = get_excise_duty(current_balance)
            total_excise_duty += excise_this_month
            current_balance -= excise_this_month

        schedule.append({
            'month': month,
            'deposit': 0 if month > 1 else principal,
            'total_deposited': total_deposited,
            'gross_interest': monthly_interest,
            'tax': monthly_tax,
            'excise': excise_this_month,
            'ending_balance': current_balance
        })

    maturity_gross = total_deposited + total_gross_interest
    total_deductions = total_tax_deducted + total_excise_duty
    take_home = current_balance

    return {
        'type': 'FDR',
        'principal': principal,
        'duration_months': duration_months,
        'annual_rate': annual_rate,
        'has_tin': has_tin,
        'total_deposited': total_deposited,
        'gross_interest': total_gross_interest,
        'tax_deducted': total_tax_deducted,
        'excise_duty': total_excise_duty,
        'total_deductions': total_deductions,
        'maturity_gross': maturity_gross,
        'take_home': take_home,
        'schedule': schedule
    }

if __name__ == '__main__':
    dps_res = calculate_dps(5000, 9.0, 36, has_tin=True)
    print("--- DPS Test ---")
    print(f"Total Deposited: {dps_res['total_deposited']:,.2f}")
    print(f"Gross Interest:  {dps_res['gross_interest']:,.2f}")
    print(f"Source Tax 10%:  {dps_res['tax_deducted']:,.2f}")
    print(f"Excise Duty:     {dps_res['excise_duty']:,.2f}")
    print(f"Take Home:       {dps_res['take_home']:,.2f}")

    fdr_res = calculate_fdr(500000, 10.0, 12, has_tin=False)
    print("\n--- FDR Test ---")
    print(f"Principal:       {fdr_res['principal']:,.2f}")
    print(f"Gross Interest:  {fdr_res['gross_interest']:,.2f}")
    print(f"Source Tax 15%:  {fdr_res['tax_deducted']:,.2f}")
    print(f"Excise Duty:     {fdr_res['excise_duty']:,.2f}")
    print(f"Take Home:       {fdr_res['take_home']:,.2f}")
